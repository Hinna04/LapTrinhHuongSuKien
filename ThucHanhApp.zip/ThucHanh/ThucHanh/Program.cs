﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ThucHanh
{
    internal class Program
    {
        /*string ConnectionString = "Data Source = DESKTOP-RI5PGH8\SQLEXPRESS" +
                                  "Initial Catalog = SinhVien" +
                                  "Intergrated Security = True";
        string ConnectionString2 = "Data Source=DESKTOP-RI5PGH8\SQLEXPRESS;Initial Catalog=SinhVien;Integrated Security=True";*/
        static void Main(string[] args)
        {
            string connectionString = ConfigurationManager
                                      .ConnectionStrings["SinhVien_connectionString"]
                                      .ConnectionString;
            string maSV, ngaySinh, gioiTinh;
            Console.Write("Nhap ma sinh vien: ");
            maSV = Console.ReadLine();
            while (KiemTraKhoaChinh_SV(connectionString, maSV))
            {
                Console.Write("Nhap lai ma sinh vien: ");
                maSV = Console.ReadLine();
            }
            Console.Write("Nhap ngay sinh: ");
            DateTime dateTime = Convert.ToDateTime(Console.ReadLine());
            ngaySinh = dateTime.ToString("yyyy/mm/dd");
            Console.Write("Nhap gioi tinh: ");
            gioiTinh = Console.ReadLine();
            bool i = ThemSinhVien(connectionString, maSV, ngaySinh, IsGender(gioiTinh));
            if (i)
            {
                throw new NotImplementedException();
            }
        }

        private static bool IsGender(string gender)
        {
            bool index;
            if (gender.ToLower() == "Nam")
            {
                index = true;
            }
            else
            {
                index = false;
            }
            return index;
        }

        private static bool ThemSinhVien(string connectionStrings, string maSV, string ngaySinh, string gioiTinh)
        {
            //string insert_command = "Insert into tblSinhVien (sMaSV, dNgaySinh, bGioiTinh)" +
            //                         "Values('" + maSV + "', '" + ngaySinh + "', '" + gioiTinh + "')";
            string insert_proc = "Insert_SinhVien";
            using (SqlConnection conn = new SqlConnection(connectionStrings))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    //cmd.Connection = conn;
                    cmd.CommandText = insert_proc;
                    cmd.CommandType = CommandType.StoredProcedure;
                    //khoi tao va truyen tham so cho proc
                    cmd.Parameters.Add("@maSV", SqlDbType.VarChar, 30).Value = maSV;
                    cmd.Parameters.AddWithValue("@ngaySinh", ngaySinh);
                    cmd.Parameters.AddWithValue("@gioiTinh", gioiTinh);

                    conn.Open();
                    int i = cmd.ExecuteNonQuery();
                    conn.Close();
                    return (i > 0);
                }
            }
        }

        private static bool KiemTraKhoaChinh_SV(string connectionString, string maSV)
        {
            string checkID_proc = "KiemTraKhoaChinh_SinhVien";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                //conn.ConnectionString = connectionString;
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = checkID_proc;
                    cmd.CommandType = CommandType.StoredProcedure;

                    //truyen tham so
                    cmd.Parameters.AddWithValue("@maSV", maSV);

                    conn.Open();
                    bool i = (cmd.ExecuteScalar() != null); // -> co du lieu tra ve
                    conn.Close();
                    if (i)
                    {
                        //throw new Exception("Ma sinh vien: " + maSV + " da ton tai!");
                        Console.WriteLine("Ma sinh vien: " + maSV + " da ton tai!");
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }

        public static void HienThiDS_SinhVien(string connectionstring)
        {
            string query_tblSV = "Select_tblSinhVien";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = query_tblSV;
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                Console.WriteLine("{0}\t{1}\t{2}"),
                                    reader["sMaSV"],
                                    reader["dNgaySinh"],
                                    reader["bGioiTinh"];
                            }
                        }
                    }
                    conn.Close();
                }
            }

        }

        public static bool Update_SinhVien(string connectionStrings, string maSV, string ngaySinh, string gioiTinh)
        {
            string Update_proc = "Update_tblSinhVien";
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = Update_proc;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@maSV", SqlDbType.VarChar, 30).Value = maSV;
                    cmd.Parameters.AddWithValue("@ngaySinh", ngaySinh);
                    cmd.Parameters.AddWithValue("@gioiTinh", gioiTinh);
                    conn.Open();

                    conn.Close();
                }
            }
        }

        public static void HienDDSV_NgatKetNoi(string connectionString)
        {
            string select_proc = "Select_tblSinhVien";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                //conn.ConnectionString = connectionString;
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = select_proc;
                    cmd.CommandType = CommandType.StoredProcedure;
                    using(SqlDataAdapter adapter = new SqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;
                        using(DataTable table = new DataTable())
                        {
                            adapter.Fill(table);
                            if (table.Rows.Count > 0)
                            {
                                //Hien thi du lieu co dieu kien
                                using (DataView dataView = table.DefaultView)
                                {
                                    dataView.RowFilter = "bGioiTinh = 1 and 'nu'";
                                    dataView.Sort = "dNgaySinh ASC";
                                    // Hien thi du lieu ra man hinh
                                    foreach (DataRowView row in dataView)
                                    {
                                        Console.WriteLine("{0}\t{1}",
                                                        row["sMaSV"],
                                                        row["dNgaySinh"]);
                                    }
                                }
                                // Hien thi du lieu ra man hinh
                                foreach (DataRow row in table.Rows)
                                {
                                    Console.WriteLine("{0}\t{1}",
                                                    row["sMaSV"],
                                                    row["dNgaySinh"]);
                                }
                            }
                            else
                            {
                                // Khong ton tai ban ghi nao
                            }
                        }
                    }
                }
            }
        }

        private static bool XoaSinhVienNgatKetNoi(string connectionString, string masv)
        {
            string delete_proc = "Delete_tblSinhVien";
            string select_proc = "Select_tblSinhVien";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = select_proc;
                    cmd.CommandType = CommandType.StoredProcedure;
                    using(SqlDataAdapter adapter = new SqlDataAdapter())
                    {
                        adapter.SelectCommand = cmd;
                        using (DataTable tblSinhVien = new DataTable("tblSinhVien"))
                        {
                            adapter.Fill(tblSinhVien);
                            using (DataSet dataSet = new DataSet())
                            {
                                dataSet.Tables.Add(tblSinhVien);

                                //tim ma so sv can xoa
                                tblSinhVien.PrimaryKey = new DataColumn[] { tblSinhVien.Columns["sMaSV"] };
                                DataRow row = tblSinhVien.Rows.Find(masv);
                                row.Delete();

                                //Dong bo du lieu len CSDL su dung DeleteCommand
                                cmd.CommandText = delete_proc;
                                cmd.Parameters.Clear();
                                cmd.Parameters.AddWithValue("@masv", masv);

                                adapter.DeleteCommand = cmd;
                                int i = adapter.Update(dataSet, "tblSinhVien");

                                return i > 0;
                            }
                        }
                    }
                }
            }
            return true;
        }

        private static bool ThemSinhVienNgatKetNoi (string connectionString, string masv, string ngaysinh)
        {
            string insert_proc = "Insert_tblSinhVien";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = new SqlCommand("select * from tblSinhVien", conn);
                    DataTable dtSinhVien = new DataTable("tblSinhVien");
                    adapter.Fill(dtSinhVien);

                    //Khoi tao dataset va add tung databse vao dataset
                    DataSet dataSet = new DataSet();
                    dataSet.Tables.Add(dtSinhVien);

                    //Them ban ghi moi vao datatable
                    DataRow row = dtSinhVien.NewRow();
                    row["sMaSV"] = masv;
                    row["dNgaySinh"] = ngaysinh;
                    dtSinhVien.Rows.Add(row);

                    //dong bo du lieu
                    using()
                }
            }
        }
    }
}